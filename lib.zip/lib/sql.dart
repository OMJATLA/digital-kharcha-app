// // import 'package:mysql1/mysql1.dart';

// // class Sql {
// //   static MySqlConnection? conn;

// //   static Future<void> connectionOfSql() async {
// //     try {
// //       conn = await MySqlConnection.connect(
// //         ConnectionSettings(
// //           host: 'localhost',
// //           port: 3306,
// //           user: 'root',
// //           password: 'om',
// //           db: 'kharchaDB',
// //         ),
// //       );
// //       final result = await conn!.query("Select * from kharchaDB.users");
// //       // final result = await conn!.query(
// //       //     'INSERT INTO users (name, email) VALUES (?, ?)',
// //       //     ['John Doe', 'john@example.com']);

// //       // if (result.affectedRows! > 0) {
// //       //   print('User added successfully!');
// //       // } else {
// //       //   print('Failed to add user.');
// //       // }
// //     } catch (e) {
// //       print('Error: $e');
// //     } finally {
// //       await conn?.close();
// //     }
// //   }
// // }

// // import 'package:mysql1/mysql1.dart';
// import 'package:mysql_client/mysql_client.dart';

// class Sql {
//   static MySQLConnection? conn;

//   static void connectionOfSql() async {
//     conn = await MySQLConnection.createConnection(
//       host: "127.0.0.1",
//       port: 3306,
//       userName: "root",
//       password: "om",
//       databaseName: "kharchaDB", // optional
//     );
//     await conn!.connect();

//     var result = await conn!.execute("SELECT * FROM kharchaDB.users", {}, true);

//     result.rowsStream.listen((row) {
//       print(row.colByName('name'));
//       // print(row.)
//     });
//   }
// }

import 'package:flutter/foundation.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import 'model.dart';

class SqliteService {
  static RxList<DailyChargesInfo> listOfTransactions = <DailyChargesInfo>[].obs;
  Future<Database> initializeDB() async {
    debugPrint("Connecting SQL");
    String path = await getDatabasesPath();

    return openDatabase(
      join(path, 'kharchaDB.db'),
      onCreate: (database, version) async {
        await database.execute(
          "CREATE TABLE DailyCharges(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL, amount TEXT NOT NULL, description_where_used_the_money TEXT NOT NULL)",
        );
      },
      version: 1,
    );
  }

//inserting...............................
  Future<int> createItem(DailyChargesInfo note) async {
    int result = 0;
    final Database db = await initializeDB();
    final id = await db.insert('DailyCharges', note.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
    return 0;
  }

  Future<List<DailyChargesInfo>> getItems() async {
    final db = await initializeDB();
    final List<Map<String, Object?>> queryResult = await db.query(
      'DailyCharges',
    );
    print(queryResult);
    return queryResult.map((e) => DailyChargesInfo.fromMap(e)).toList();
  }

  Future<void> truncateTable() async {
    final db = await initializeDB();
    try {
      await db.delete("DailyCharges"); // Truncate the "Notes" table
    } catch (err) {
      debugPrint("Something went wrong when truncating the table: $err");
    }
  }
}
