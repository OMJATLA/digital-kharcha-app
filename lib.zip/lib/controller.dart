import 'package:digital_kharcha_app/model.dart';
import 'package:digital_kharcha_app/sql.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:intl/intl.dart';
import 'package:telephony/telephony.dart';

RxList<DailyChargesInfo> sms = <DailyChargesInfo>[].obs;

class HomeController extends GetxController {
  RxDouble totalAmountOfToday = 0.0.obs;
  static SqliteService sqliteService = SqliteService();
  Telephony telephony = Telephony.instance;
  // Use RxList to make the sms list reactive

  @override
  void onInit() {
    super.onInit();
    debugPrint("On init");

    connectSQL();
    debugPrint("Sql Connection Done......................................");
    // Listen for incoming SMS

    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        // Add the new SMS message to the sms list
        // sms.add(message.body.toString());

        addAmountToDB(message: message.body.toString());
      },
      listenInBackground: true,
      onBackgroundMessage: listenInBack,
    );
    debugPrint(
        "Telehone msg listening Connection Done......................................");
  }

// connection to sql
  void connectSQL() async {
    await sqliteService.initializeDB();
    SqliteService.listOfTransactions.value = await sqliteService.getItems();
    addTotalAmountOfToday();
  }

  void addAmountToDB({required String message}) async {
    String keyword = "debited";
    // message =
    //     "Your a/c no. XXXXXXXX2635 is debited for Rs.41.00 on 28-03-2024 20:32:47 (UPI Ref no 408879605999)";

    // Get.defaultDialog(title: message);
    debugPrint("Message is " + message);
    // Check if the message contains the keyword
    if (message.contains(keyword)) {
      // Find the index of the keyword
      int keywordIndex = message.indexOf(keyword);

      // Extract the substring from the keyword to the end of the message
      String amountSubstring = message.substring(keywordIndex);

      // Find the index of 'Rs.' in the substring
      int rsIndex = amountSubstring.indexOf('Rs.');

      // Extract the amount substring starting from 'Rs.'
      String amount = amountSubstring.substring(rsIndex + 3).split(' ')[0];

      print("Amount debited: Rs.$amount");

      // int sizeOfRow =
      await sqliteService.createItem(DailyChargesInfo(
          // id: 1,
          amount: amount,
          date: formattedDate(),
          descriptionWhereUsedTheMoney: message));
      debugPrint("inserted");
      SqliteService.listOfTransactions.value =
          await HomeController.sqliteService.getItems();
      addTotalAmountOfToday();
    } else {
      print("Keyword 'debited' not found in the message.");
    }
  }

  void addTotalAmountOfToday() {
    totalAmountOfToday.value = 0.0;
    for (DailyChargesInfo element in SqliteService.listOfTransactions) {
      print('udghudbwuuuuuub');
      print(element);
      totalAmountOfToday.value += double.parse(element.amount);
    }
  }

  String formattedDate() {
    // Get current DateTime
    DateTime now = DateTime.now();

    // Format DateTime to desired format
    String formattedDate = DateFormat('dd-MM-yyyy').format(now);

    return formattedDate;
  }
}

// This function is called when a new SMS is received in the background
void listenInBack(SmsMessage message) async {
  HomeController().addAmountToDB(message: message.body.toString());
}
