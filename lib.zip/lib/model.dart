class DailyChargesInfo {
  int id = 0;
  final String date;
  final String amount;
  final String descriptionWhereUsedTheMoney;

  DailyChargesInfo({
    // this.id = 0,
    required this.date,
    required this.amount,
    required this.descriptionWhereUsedTheMoney,
  });
  @override
  String toString() => {
        "id : $id , date : $date, amount : $amount, descriptionWhereUsedTheMoney : $descriptionWhereUsedTheMoney"
      }.toString();
  DailyChargesInfo.fromMap(Map<String, dynamic> map)
      : id = map['id'],
        date = map['date'],
        amount = map['amount'],
        descriptionWhereUsedTheMoney = map['description_where_used_the_money'];

  Map<String, dynamic> toMap() {
    return {
      'date': date,
      'amount': amount,
      'description_where_used_the_money': descriptionWhereUsedTheMoney,
    };
  }
}
