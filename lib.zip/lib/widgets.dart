import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomIconTextWidget extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String text;
  final Color textColor;
  final String amount;
  final Color amountColor;

  const CustomIconTextWidget({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.text,
    required this.textColor,
    required this.amount,
    required this.amountColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Container(
              height: 25,
              width: 23,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: iconColor,
              ),
              child: Center(
                child: Icon(
                  icon,
                  size: 15,
                  color: Colors.white,
                ),
              ),
            ),
            Text(
              text,
              style: TextStyle(color: textColor),
            ).paddingSymmetric(horizontal: 7),
          ],
        ).paddingOnly(top: 30),
        Text(
          amount,
          style: TextStyle(
            color: amountColor,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
