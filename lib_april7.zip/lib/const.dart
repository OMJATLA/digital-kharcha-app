// Define color variables
import 'dart:ui';

final Color kmedBlueColor = const Color(0xff358882).withBlue(255);
final Color kdarkBlueColor = const Color(0xff2f7e79).withBlue(255);
const Color klightBlueColor = Color(0xffd0e5e4); // text
final Color kiconColor = const Color(0xff4e918d).withBlue(255);
